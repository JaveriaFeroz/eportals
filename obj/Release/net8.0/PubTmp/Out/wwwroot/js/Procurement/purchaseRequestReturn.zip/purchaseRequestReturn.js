﻿// CORRECTED JAVASCRIPT CODE
$(document).ready(function () {
    console.log('Return functionality JavaScript loaded');
    initializeReturnFunctionality();

    function initializeReturnFunctionality() {
        // Handle return button click
        $(document).on('click', '#returnButton, [data-bs-target="#returnToSpecificUserModal"]', function (e) {
            e.preventDefault();
            console.log('Return button clicked');

            const purchaseRequestId = $(this).data('purchase-request-id') || $('#purchaseRequestId').val();
            console.log('Purchase Request ID:', purchaseRequestId);

            if (!purchaseRequestId) {
                console.error('Purchase Request ID not found');
                showError('Purchase Request ID is required');
                return;
            }

            showReturnToSpecificUserModal(purchaseRequestId);
        });

        // Reset modal when hidden
        $('#returnToSpecificUserModal').on('hidden.bs.modal', function () {
            console.log('Modal hidden, resetting');
            resetReturnToSpecificUserModal();
        });

        // Handle form submission
        $('#confirmReturnButton').on('click', function (e) {
            e.preventDefault();
            console.log('Confirm return button clicked');
            processReturnWithValidation();
        });
    }

    function showReturnToSpecificUserModal(purchaseRequestId) {
        console.log('🎯 Showing return modal for PR ID:', purchaseRequestId);

        if (!purchaseRequestId) {
            console.error('Purchase Request ID is required');
            showError('Purchase Request ID is required');
            return;
        }

        clearMessages();
        $('#returnToSpecificUserModal').modal('show');
        showLoadingState();

        // Load previous users with better error handling
        loadPreviousUsers(purchaseRequestId)
            .then(function (data) {
                console.log('✅ Previous users loaded successfully:', data);
                if (data && data.success) {
                    populateUserDropdown(data.users);
                    $('#purchaseRequestId').val(purchaseRequestId);
                } else {
                    showError(data?.message || 'Failed to load previous users');
                }
            })
            .catch(function (error) {
                console.error('❌ Error loading previous users:', error);
                showError('An error occurred while loading previous users');
            })
            .finally(function () {
                hideLoadingState();
            });
    }

    // FIXED: Single, complete function declaration
    function loadPreviousUsers(purchaseRequestId) {
        console.log('🚀 loadPreviousUsers called with ID:', purchaseRequestId);

        if (!purchaseRequestId) {
            console.error('❌ No purchaseRequestId provided');
            return Promise.reject('Purchase Request ID is required');
        }

        // Construct URL more reliably
        const baseUrl = window.location.origin;
        const url = `${baseUrl}/Procurement/PurchaseRequest/GetPreviousWorkflowUsers`;

        console.log('🌐 Making AJAX request to:', url);
        console.log('📝 With parameters:', { purchaseRequestId: purchaseRequestId });

        return $.ajax({
            url: url,
            type: 'GET',
            data: { purchaseRequestId: purchaseRequestId },
            dataType: 'json',
            timeout: 30000, // 30 second timeout
            beforeSend: function (xhr) {
                console.log('📤 Sending AJAX request...');
                // Add anti-forgery token if needed
                var token = $('input[name="__RequestVerificationToken"]').val();
                if (token) {
                    xhr.setRequestHeader('RequestVerificationToken', token);
                }
            }
        }).done(function (data) {
            console.log('✅ AJAX Success:', data);
        }).fail(function (xhr, status, error) {
            console.error('❌ AJAX Error Details:', {
                status: status,
                error: error,
                responseStatus: xhr.status,
                responseText: xhr.responseText,
                url: url,
                readyState: xhr.readyState,
                statusText: xhr.statusText
            });

            // Try to parse error response
            let errorMessage = 'An error occurred while loading previous users';
            try {
                if (xhr.responseText) {
                    const errorResponse = JSON.parse(xhr.responseText);
                    errorMessage = errorResponse.message || errorMessage;
                }
            } catch (parseError) {
                console.warn('Could not parse error response:', parseError);
            }

            throw new Error(errorMessage);
        });
    }

    function populateUserDropdown(users) {
        console.log('🔄 Populating dropdown with users:', users);

        const dropdown = $('#returnToUserId');
        dropdown.empty();
        dropdown.append('<option value="">-- Select User to Return To --</option>');

        if (users && users.length > 0) {
            users.forEach(function (user) {
                dropdown.append(`<option value="${user.value}" data-full-text="${user.text}">${user.text}</option>`);
            });

            dropdown.prop('disabled', false);
            $('#returnUserSection').show();
            initializeUserSearchFilter();
            console.log('✅ Dropdown populated successfully with', users.length, 'users');
        } else {
            dropdown.append('<option value="">No previous users found</option>');
            dropdown.prop('disabled', true);
            showWarning('No previous users available for return.');
            $('#returnUserSection').hide();
            console.log('⚠️ No users found to populate dropdown');
        }
    }

    // Rest of your functions remain the same...
    function processReturn() {
        console.log('Processing return');

        const form = $('#returnForm');
        const formData = form.serialize();

        console.log('Form data:', formData);

        showProcessingState();

        $.ajax({
            url: form.attr('action'),
            type: 'POST',
            data: formData,
            success: function (response) {
                console.log('Return processed successfully:', response);
                $('#returnToSpecificUserModal').modal('hide');

                if (typeof response === 'string') {
                    showSuccess('Purchase request returned successfully');
                } else if (response.success !== false) {
                    showSuccess(response.message || 'Purchase request returned successfully');
                } else {
                    showError(response.message || 'Failed to process return.');
                }

                setTimeout(function () {
                    window.location.reload();
                }, 1500);
            },
            error: function (xhr, status, error) {
                console.error('Error processing return:', {
                    status: status,
                    error: error,
                    responseText: xhr.responseText
                });

                let errorMessage = 'An error occurred while processing the return.';

                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                } else if (xhr.responseText) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        errorMessage = response.message || errorMessage;
                    } catch (e) {
                        // Use default error message if JSON parsing fails
                    }
                }
                showError(errorMessage);
            },
            complete: function () {
                hideProcessingState();
            }
        });
    }

    function resetReturnToSpecificUserModal() {
        console.log('Resetting return modal');

        $('#returnToUserId').empty().prop('disabled', true);
        $('#returnComments').val('');
        $('#purchaseRequestId').val('');
        $('#returnUserSection').hide();
        clearMessages();
        $('#confirmReturnButton').prop('disabled', true);

        const dropdown = $('#returnToUserId');
        if (typeof $.fn.select2 !== 'undefined' && dropdown.data('select2')) {
            dropdown.select2('destroy');
        }
    }

    function showLoadingState() {
        console.log('Showing loading state');
        $('#loadingSpinner').show();
        $('#returnButton, [data-bs-target="#returnToSpecificUserModal"]').prop('disabled', true);
        $('#returnUserSection').hide();
    }

    function hideLoadingState() {
        console.log('Hiding loading state');
        $('#loadingSpinner').hide();
        $('#returnButton, [data-bs-target="#returnToSpecificUserModal"]').prop('disabled', false);
    }

    function showProcessingState() {
        $('#confirmReturnButton').prop('disabled', true)
            .html('<span class="spinner-border spinner-border-sm me-2" role="status"></span>Processing...');
        $('#cancelReturnButton').prop('disabled', true);
    }

    function hideProcessingState() {
        $('#confirmReturnButton').prop('disabled', false).html('<i class="fas fa-undo me-2"></i> Confirm Return');
        $('#cancelReturnButton').prop('disabled', false);
    }

    // Alert and Validation Functions
    function showSuccess(message) {
        showAlert('success', message);
    }

    function showError(message) {
        showAlert('danger', message);
    }

    function showWarning(message) {
        showAlert('warning', message);
    }

    function showValidationError(message) {
        $('#returnToSpecificUserModalError').removeClass('d-none').find('.alert-text').html(message);
    }

    function showAlert(type, message) {
        $('.alert').remove();
        const alertHtml = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                <i class="fas fa-${getAlertIcon(type)} me-2"></i>
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;

        $('main, .container-fluid').first().prepend(alertHtml);

        setTimeout(function () {
            $('.alert').fadeOut(function () {
                $(this).remove();
            });
        }, 5000);
    }

    function getAlertIcon(type) {
        switch (type) {
            case 'success': return 'check-circle';
            case 'danger': return 'exclamation-triangle';
            case 'warning': return 'exclamation-circle';
            case 'info': return 'info-circle';
            default: return 'info-circle';
        }
    }

    function clearMessages() {
        $('#returnToSpecificUserModalError').addClass('d-none').find('.alert-text').empty();
        $('.alert').remove();
    }

    function validateReturnForm() {
        let isValid = true;
        const errors = [];

        $('#returnToUserId, #returnComments').removeClass('is-invalid');
        $('.invalid-feedback').remove();

        const selectedUser = $('#returnToUserId').val();
        if (!selectedUser) {
            errors.push('Please select a user to return the request to.');
            $('#returnToUserId').addClass('is-invalid');
            $('#returnToUserId').after('<div class="invalid-feedback">Please select a user to return to.</div>');
            isValid = false;
        }

        const comments = $('#returnComments').val().trim();
        if (!comments) {
            errors.push('Please provide comments for the return.');
            $('#returnComments').addClass('is-invalid');
            $('#returnComments').after('<div class="invalid-feedback">Please provide comments for the return.</div>');
            isValid = false;
        } else if (comments.length < 10) {
            errors.push('Comments must be at least 10 characters long.');
            $('#returnComments').addClass('is-invalid');
            $('#returnComments').after('<div class="invalid-feedback">Comments must be at least 10 characters long.</div>');
            isValid = false;
        }

        if (!isValid) {
            showValidationError(errors.join('<br>'));
        } else {
            $('#returnToSpecificUserModalError').addClass('d-none');
        }

        return isValid;
    }

    function processReturnWithValidation() {
        console.log('Processing return with validation');
        if (!validateReturnForm()) {
            console.log('Form validation failed');
            return;
        }
        processReturn();
    }

    // Character counter for comments
    $('#returnComments').on('input', function () {
        const currentLength = $(this).val().length;
        $('#commentCharCount').text(currentLength);

        const counter = $('#commentCharCount').parent();
        if (currentLength > 900) {
            counter.removeClass('text-muted text-warning').addClass('text-danger');
        } else if (currentLength > 700) {
            counter.removeClass('text-muted text-danger').addClass('text-warning');
        } else {
            counter.removeClass('text-warning text-danger').addClass('text-muted');
        }
    });

    // Update preview when user selection changes
    $('#returnToUserId').on('change', function () {
        const selectedOption = $(this).find('option:selected');
        const selectedText = selectedOption.data('full-text') || selectedOption.text();
        const preview = $('#selectedUserPreview');

        if ($(this).val()) {
            preview.html(`<strong class="text-primary">${selectedText}</strong>`);
            if ($('#returnComments').val().trim().length >= 10) {
                $('#confirmReturnButton').prop('disabled', false);
            }
        } else {
            preview.html('<em class="text-muted">Select a user above</em>');
            $('#confirmReturnButton').prop('disabled', true);
        }
    });

    // Check comments on input to enable/disable button
    $('#returnComments').on('input', function () {
        const commentsLength = $(this).val().trim().length;
        const selectedUser = $('#returnToUserId').val();
        if (commentsLength >= 10 && selectedUser) {
            $('#confirmReturnButton').prop('disabled', false);
        } else {
            $('#confirmReturnButton').prop('disabled', true);
        }
    });

    function initializeUserSearchFilter() {
        if (typeof $.fn.select2 !== 'undefined') {
            $('#returnToUserId').select2({
                placeholder: "Search and select user to return to...",
                allowClear: true,
                width: '100%',
                dropdownParent: $('#returnToSpecificUserModal'),
                templateResult: function (data) {
                    if (!data.id) return data.text;
                    const originalText = $(data.element).data('full-text') || data.text;
                    return $(`<div>${originalText}</div>`);
                },
                templateSelection: function (data) {
                    return data.text;
                }
            });
        }
    }

    // Add keyboard shortcuts
    $(document).on('keydown', function (e) {
        if (e.keyCode === 27 && $('#returnToSpecificUserModal').hasClass('show')) {
            $('#returnToSpecificUserModal').modal('hide');
        }

        if (e.keyCode === 13 && $('#returnToSpecificUserModal').hasClass('show')) {
            e.preventDefault();
            if (validateReturnForm()) {
                $('#confirmReturnButton').click();
            }
        }
    });

    // Initial setup
    $('#returnToUserId').trigger('change');
    $('#returnComments').trigger('input');

    console.log('✅ Return functionality initialization complete');
});